﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace task8._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите количество цифр");
            int N = Convert.ToInt32(Console.ReadLine());
            int S = 0;
            Random random = new Random();
            string path = "D:/_ОБУЧЕНИЕ/text.txt";
            using (StreamWriter sw = new StreamWriter(path))
            {
                for (int i = 0; i < N; i++)
                {
                    sw.WriteLine(random.Next(0, 100));
                }
            }
            using (StreamReader sr = new StreamReader(path))
            {
                for (int i = 0; i < N; i++)
                {
                    S = S + Int32.Parse(sr.ReadLine());
                }
            }
            Console.WriteLine($"Сумма чисел в файле text.txt равна: {S}");
            Console.ReadKey();
        }
    }
}
