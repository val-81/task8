﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace task8._1
{
    class Program
    {
        static void Main(string[] args)
        {
            DirectoryInfo a = new DirectoryInfo("D:/_Проекты");
            Console.WriteLine("Каталоги");
            foreach (var item in a.GetDirectories())
            {
                Console.WriteLine(item.Name);
                Console.WriteLine("Подкаталоги");
                foreach (var it in item.GetDirectories())
                    Console.WriteLine(it.Name);
                Console.WriteLine();
            }
            Console.WriteLine("Файлы");
            foreach (var item in a.GetFiles())
            {
                Console.WriteLine(item.Name);
            }
            Console.ReadLine();
        }
    }
}
